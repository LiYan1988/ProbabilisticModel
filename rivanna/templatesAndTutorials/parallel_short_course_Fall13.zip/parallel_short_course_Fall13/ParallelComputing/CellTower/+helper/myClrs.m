function clrs=myClrs

% Copyright 2013 The MathWorks, Inc.

clrs=[...
     255 204 0
     153 50 0
     93 70 95
     27 48 73
     171 200 209
     23 140 100
     77 78 68];
 
clrs=clrs([1 2 3 5],:)/255;

    