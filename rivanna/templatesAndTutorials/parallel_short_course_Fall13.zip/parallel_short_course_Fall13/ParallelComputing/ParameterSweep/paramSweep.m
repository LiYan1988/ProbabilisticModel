
%% Parameter Sweep of ODEs
% This is a parameter sweep study of a 2nd order ODE system.
%
% $m\ddot{x} + b\dot{x} + kx = 0$
%
% We solve the ODE for a time span of 0 to 25 seconds, with initial
% conditions $x(0) = 0$ and $\dot{x}(0) = 1$. We sweep the parameters $b$
% and $k$ and record the peak values of $x$ for each condition. At the end,
% we plot a surface of the results.
%
%
% Copyright 2009-2013 The MathWorks, Inc.

%% Initialize Problem
bNum  = 60;
kNum  = 60;
m     =                    5;    % mass
bVals = linspace(0.1, 5, bNum);  % damping values
kVals = linspace(1.5, 5, kNum);  % stiffness values
[bGrid, kGrid] = meshgrid(bVals, kVals);
peakVals = nan(size(kGrid));

%% Parameter Sweep

t=tic;
parfor idx = 1:numel(kGrid)
  % Solve ODE
  [T,Y] = ode45(@(t,y) odesystem(t, y, m, bGrid(idx), kGrid(idx)), ...
    [0, 25], ...  % simulate for 25 seconds
    [0, 1]) ;      % initial conditions
 
  % Determine peak value
  peakVals(idx) = max(Y(:,1));
end
toc(t)



%% Visualize
close all
visualizeParamSweep(gca,bVals, kVals, peakVals);




