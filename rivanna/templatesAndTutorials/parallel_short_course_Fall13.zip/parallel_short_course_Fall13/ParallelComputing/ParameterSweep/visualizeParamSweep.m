function hTopAxes = visualizeParamSweep(hTopAxes, bVals, kVals, peakVals)
% hTopAxes=visualizeParamSweep(hTopAxes,bVals, kVals, peakVals);
% Plotter for ODE parameter sweep examples
%
% Copyright 2009-2013 The MathWorks, Inc.

surf(hTopAxes,bVals, kVals, peakVals, 'EdgeColor', 'none');
xlabel(hTopAxes,'Damping (b)');
ylabel(hTopAxes,'Stiffness (k)');
zlabel(hTopAxes,'Peak Response');
title('Peak Values for Solutions to $m\ddot{x} + b\dot{x} + kx = 0$', ...
      'Interpreter', 'latex', 'FontSize', 16, 'FontWeight', 'Bold' ...
      );
view(hTopAxes,50, 30)
end

