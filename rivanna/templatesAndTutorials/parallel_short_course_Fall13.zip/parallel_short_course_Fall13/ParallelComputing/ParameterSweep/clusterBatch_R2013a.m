%% Batch processing demo utilizing the ODE System example
% Copyright 2013 The MathWorks, Inc.

%% Submit job (1 worker)

fprintf('Submitting batch job on 1 worker... ');

% This connects to a cluster with the profile "R13b_32Workers"
job1 = batch('paramSweepParallel', 4, {100, 100, []}, ...
    'Profile', 'R13b_32Workers');

fprintf('Submitted!\n');

%% Submit job (30 workers)

fprintf('Submitting batch job on 30 workers... ');

% This connects to a cluster with the profile "R13b_32Workers"
job2 = batch('paramSweepParallel', 4, {100, 100, []}, ...
    'Matlabpool', 30, ...
    'Profile', 'R13b_32Workers');

fprintf('Submitted!\n');

%% Plot data when job is finished
% See the function definition for paramSweepParallel.m for the definition
%   of the 4 output variables

wait(job2);  % make sure job2 is finished
jobOutput2=fetchOutputs(job2);

close all;
visualizeParamSweep(gca, jobOutput2{2:end});

%% Compare Results

wait(job1);  % make sure job2 is finished
jobOutput1=fetchOutputs(job1);

fprintf('Computation time on 1 worker  : %0.2f sec\n', jobOutput1{1});
fprintf('Computation time on 30 workers: %0.2f sec\n', jobOutput2{1});

%% Clean Up

delete(job1);
delete(job2);